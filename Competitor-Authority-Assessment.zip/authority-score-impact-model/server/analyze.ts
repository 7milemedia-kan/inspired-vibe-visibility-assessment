/**
 * Authority Signal Engine
 * ------------------------------------------------------------------
 * Takes a company URL, gathers publicly visible signals, and returns a
 * 0-10 AI Authority / Thought Leadership Presence Score.
 *
 * Everything is derived from observable evidence on the public web.
 * No black-box scoring: every point awarded is traceable to a signal.
 */

import net from "node:net";
import { lookup as dnsLookup } from "node:dns/promises";

const UA =
  "Mozilla/5.0 (compatible; AuthorityScoreBot/1.0; +https://inspiredvibe.com) AppleWebKit/537.36 Chrome/124 Safari/537.36";

export type Pillar = {
  key: string;
  label: string;
  earned: number;
  max: number;
  status: "strong" | "moderate" | "weak" | "absent";
  /** One factual sentence describing what was actually found. */
  summary: string;
  /** Plain-language cost of scoring at this level. */
  consequence: string;
  evidence: string[];
};

export type ScoreResult = {
  companyName: string;
  url: string;
  domain: string;
  audience: "B2B" | "B2C" | "Mixed" | "Unclear";
  audienceNote: string;
  /** Plain-language answer to "do people understand who it's for?" */
  audienceAnswer: string;
  sellingRealOffer: "Yes" | "Likely" | "Unclear";
  sellingNote: string;
  /** Plain-language answer to "do people understand what they do?" */
  offerAnswer: string;
  /** Competitive standing verdict shown in the third summary box. */
  standing: string;
  standingNote: string;
  score: number;
  band: string;
  bandLabel: string;
  headline: string;
  rationale: string;
  presenceNotes: string[];
  recommended: boolean;
  recommendation: string;
  pillars: Pillar[];
  biggestGap: string;
  confidence: "High" | "Moderate" | "Limited";
  confidenceNote: string;
  pagesScanned: number;
};

/* ------------------------------------------------------------------ */
/* consequence copy — what it costs to score at each level             */
/* ------------------------------------------------------------------ */

type Tier = "absent" | "weak" | "moderate" | "strong";

const CONSEQUENCE: Record<string, Record<Tier, string>> = {
  social: {
    absent:
      "Buyers who go looking for them on social find nothing. Most read that as a company that is smaller, newer, or less established than it really is — and they move on without ever asking.",
    weak:
      "There is too little here for a buyer to confirm they are active and credible. Doubt at this stage almost always gets resolved in a competitor's favour.",
    moderate:
      "This competitor's channels do not cover everywhere buyers look, so some buyers may miss the company during their research.",
    strong:
      "Buyers can find them wherever they look, which removes the earliest and cheapest reason to disqualify them.",
  },
  socialEff: {
    absent:
      "Profiles that show no real activity read as abandoned. That is worse than having no social at all — it tells a buyer they start things and drop them.",
    weak:
      "This competitor's accounts exist but show little activity. Buyers see logos and links, with limited evidence of expertise to encourage contact.",
    moderate:
      "They are active but not memorable. Buyers recognise the name without attaching a point of view to it, so they compete on price instead of authority.",
    strong:
      "Their social activity is doing real work. Buyers arrive already familiar with how they think, which shortens the sales conversation considerably.",
  },
  content: {
    absent:
      "There is nothing for a buyer to read and nothing for search to rank. They are invisible at the exact moment people are researching the problem they solve.",
    weak:
      "Thin content means buyers land, learn very little, and leave. They are paying to acquire attention they have no way to hold.",
    moderate:
      "They publish, but not deeply enough to own a topic. Buyers get their answers from a competitor's content and carry that competitor's framing into the deal.",
    strong:
      "Their content does the early selling for them. Buyers arrive educated, and educated buyers close faster and negotiate harder on value than on price.",
  },
  podcast: {
    absent:
      "No show means no long-form access to their thinking. Competitors who host one are banking thirty minutes of trust per episode that they never get.",
    weak:
      "A podcast that is mentioned but not really running builds nothing. Buyers who go looking for it find a dead end, which costs more credibility than never starting.",
    moderate:
      "The show exists but is not consistent enough to build an audience. Buyers who find one episode have no reason to come back for a second.",
    strong:
      "Their show gives buyers sustained, unhurried access to how they think — the highest-trust format available to them, and one most competitors will not commit to.",
  },
  video: {
    absent:
      "When buyers cannot see video, they never get a sense of the people behind the brand. That missing human read is enough to send them to a competitor who let them in.",
    weak:
      "There is barely enough video for a buyer to judge whether they would want to work with them. They will find that judgement somewhere else.",
    moderate:
      "Video appears but is not a habit. Buyers get a partial read on their team and fill the rest of the gap with assumptions they do not control.",
    strong:
      "Buyers can see and hear their team before the first call, so they walk in already comfortable with who they are dealing with.",
  },
  external: {
    absent:
      "Every claim about them currently comes from them. Buyers heavily discount self-reported credibility, which means their strongest proof is the one they trust least.",
    weak:
      "There is almost no outside voice confirming they are good at this. Buyers who want reassurance have nowhere to go and will look at a competitor who has it.",
    moderate:
      "Some outside proof exists, but not enough to settle a buying committee's doubts. The people who did not meet them have nothing to point at.",
    strong:
      "Independent sources back up what they say about themselves, which is what turns interest into a shortlist.",
  },
};

const tierOf = (earned: number, max: number): Tier => {
  if (earned === 0) return "absent";
  const r = earned / max;
  return r >= 0.75 ? "strong" : r >= 0.4 ? "moderate" : "weak";
};

const joinList = (items: string[]): string =>
  items.length <= 1
    ? items[0] ?? ""
    : items.length === 2
    ? `${items[0]} and ${items[1]}`
    : `${items.slice(0, -1).join(", ")}, and ${items[items.length - 1]}`;

/**
 * Compose one readable summary sentence. Positives are what was found;
 * negatives are named gaps, listed separately so the sentence never reads
 * as a contradictory run-on.
 */
const summarize = (positives: string[], negatives: string[], fallback: string): string => {
  const pos = positives.filter(Boolean);
  const neg = negatives.filter(Boolean);
  if (!pos.length && !neg.length) return fallback;
  if (!pos.length) return `Missing: ${joinList(neg)}.`;
  const head = joinList(pos);
  const lead = `Found ${head}.`;
  return neg.length ? `${lead} Missing: ${joinList(neg)}.` : lead;
};

/* ------------------------------------------------------------------ */
/* fetching                                                            */
/* ------------------------------------------------------------------ */

/**
 * SSRF guard. Rejects loopback, link-local, private, carrier-grade NAT,
 * multicast/reserved, and cloud metadata addresses — including IPv6 literals,
 * IPv4-mapped IPv6, and hostnames that resolve to any of the above.
 */
function isBlockedIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const p = ip.split(".").map(Number);
    if (p.some((n) => Number.isNaN(n) || n < 0 || n > 255)) return true;
    if (p[0] === 0) return true; // this-network
    if (p[0] === 10) return true; // private
    if (p[0] === 127) return true; // loopback
    if (p[0] === 100 && p[1] >= 64 && p[1] <= 127) return true; // CGNAT
    if (p[0] === 169 && p[1] === 254) return true; // link-local + metadata
    if (p[0] === 172 && p[1] >= 16 && p[1] <= 31) return true; // private
    if (p[0] === 192 && p[1] === 0) return true; // 192.0.0.0/24, 192.0.2.0/24
    if (p[0] === 192 && p[1] === 168) return true; // private
    if (p[0] === 198 && (p[1] === 18 || p[1] === 19)) return true; // benchmark
    if (p[0] >= 224) return true; // multicast + reserved + broadcast
    return false;
  }
  if (net.isIPv6(ip)) {
    const s = ip.toLowerCase();
    if (s === "::" || s === "::1") return true;
    const mapped = s.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isBlockedIp(mapped[1]);
    if (/^(fe[89ab]|fc|fd)/.test(s)) return true; // link-local + unique-local
    if (s.startsWith("2002:")) return true; // 6to4
    if (s.startsWith("64:ff9b:")) return true; // NAT64
    return false;
  }
  return true; // unparseable — reject
}

async function hostIsSafe(hostname: string): Promise<boolean> {
  const h = hostname.toLowerCase().replace(/^\[/, "").replace(/\]$/, "");
  if (!h) return false;
  if (
    h === "localhost" ||
    h.endsWith(".localhost") ||
    h.endsWith(".local") ||
    h.endsWith(".internal") ||
    h.endsWith(".home.arpa") ||
    h.endsWith(".arpa")
  ) {
    return false;
  }
  if (net.isIP(h)) return !isBlockedIp(h);
  try {
    const addrs = await dnsLookup(h, { all: true });
    if (!addrs.length) return false;
    return addrs.every((a) => !isBlockedIp(a.address));
  } catch {
    return false;
  }
}

const FETCH_FAIL = (finalUrl: string) => ({
  ok: false,
  body: "",
  status: 0,
  finalUrl,
});

async function grab(
  url: string,
  ms = 9000
): Promise<{ ok: boolean; body: string; status: number; finalUrl: string }> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  let current = url;
  try {
    // Manual redirect handling so every hop is re-validated against the guard.
    for (let hop = 0; hop < 5; hop++) {
      let u: URL;
      try {
        u = new URL(current);
      } catch {
        return FETCH_FAIL(current);
      }
      if (u.protocol !== "https:" && u.protocol !== "http:") {
        return FETCH_FAIL(current);
      }
      if (u.username || u.password) return FETCH_FAIL(current);
      if (!(await hostIsSafe(u.hostname))) return FETCH_FAIL(current);

      const res = await fetch(current, {
        signal: ctrl.signal,
        redirect: "manual",
        headers: {
          "User-Agent": UA,
          Accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "en-US,en;q=0.9",
        },
      });

      if (res.status >= 300 && res.status < 400) {
        const loc = res.headers.get("location");
        if (!loc) return FETCH_FAIL(current);
        try {
          current = new URL(loc, current).toString();
        } catch {
          return FETCH_FAIL(current);
        }
        continue;
      }

      const body = res.ok ? (await res.text()).slice(0, 900_000) : "";
      return { ok: res.ok, body, status: res.status, finalUrl: current };
    }
    return FETCH_FAIL(current); // too many redirects
  } catch {
    return FETCH_FAIL(current);
  } finally {
    clearTimeout(t);
  }
}

export function normalizeUrl(raw: string): string | null {
  let s = (raw || "").trim();
  if (!s) return null;
  s = s.replace(/\s+/g, "");
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  try {
    const u = new URL(s);
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    if (u.username || u.password) return null;
    const host = u.hostname.toLowerCase().replace(/^\[/, "").replace(/\]$/, "");
    if (net.isIP(host)) return null; // bare IPs are never a company website
    if (!host.includes(".")) return null;
    if (
      host === "localhost" ||
      host.endsWith(".localhost") ||
      host.endsWith(".local") ||
      host.endsWith(".internal") ||
      host.endsWith(".arpa")
    ) {
      return null;
    }
    return u.origin + (u.pathname === "/" ? "" : u.pathname);
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* parsing helpers                                                     */
/* ------------------------------------------------------------------ */

const strip = (html: string) =>
  html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const meta = (html: string, name: string) => {
  const re = new RegExp(
    `<meta[^>]+(?:name|property)=["']${name}["'][^>]*content=["']([^"']*)["']`,
    "i"
  );
  const alt = new RegExp(
    `<meta[^>]+content=["']([^"']*)["'][^>]*(?:name|property)=["']${name}["']`,
    "i"
  );
  return (html.match(re)?.[1] || html.match(alt)?.[1] || "").trim();
};

const hrefs = (html: string): string[] => {
  const out: string[] = [];
  const re = /href=["']([^"']+)["']/gi;
  let m;
  while ((m = re.exec(html))) out.push(m[1]);
  return out;
};

const matchAllValues = (hay: string, re: RegExp): string[] => {
  const out: string[] = [];
  let m: RegExpExecArray | null;
  const r = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  while ((m = r.exec(hay))) out.push(m[1]);
  return out;
};

const count = (hay: string, re: RegExp) => (hay.match(re) || []).length;

/* ------------------------------------------------------------------ */
/* the analyzer                                                        */
/* ------------------------------------------------------------------ */

export async function analyze(inputUrl: string): Promise<ScoreResult> {
  const base = normalizeUrl(inputUrl)!;
  const origin = new URL(base).origin;
  const domain = new URL(base).hostname.replace(/^www\./, "");

  const home = await grab(base, 12000);
  if (!home.ok || home.body.length < 400) {
    throw Object.assign(
      new Error(
        "We couldn't reach that site or it returned no readable content. Check the URL, or the site may be blocking automated visitors."
      ),
      { code: "UNREACHABLE" }
    );
  }

  let pagesScanned = 1;
  const homeHtml = home.body;
  const homeText = strip(homeHtml);
  const homeLower = homeHtml.toLowerCase();
  const textLower = homeText.toLowerCase();
  const links = hrefs(homeHtml);

  /* --- identity ------------------------------------------------- */
  const rawTitle = (homeHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "")
    .replace(/&amp;/g, "&")
    .replace(/&#\d+;/g, "")
    .trim();
  const ogSite = meta(homeHtml, "og:site_name");
  const domainWord = domain.split(".")[0].replace(/[-_]/g, "").toLowerCase();
  const generic = /^(home|homepage|welcome|index|untitled|home page|main)$/i;

  const segments = [ogSite, rawTitle]
    .filter(Boolean)
    .flatMap((t) => t.split(/\s*[|\u2013\u2014\u00b7\u2022:]\s*|\s+-\s+/))
    .map((x) => x.replace(/\s+/g, " ").trim())
    .filter((x) => x.length >= 2 && x.length <= 42 && !generic.test(x));

  const domainMatch = segments.find(
    (x) => x.replace(/[^a-z0-9]/gi, "").toLowerCase() === domainWord
  );
  const domainContains = segments.find((x) =>
    domainWord.includes(x.replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 12))
  );
  const guessFromDomain = domain
    .split(".")[0]
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());

  let companyName =
    domainMatch ||
    domainContains ||
    (segments.length ? segments[segments.length - 1].length <= 28 && segments.length > 1
      ? segments[segments.length - 1]
      : segments[0] : "") ||
    guessFromDomain;
  companyName = companyName.replace(/\s+/g, " ").trim();
  if (!companyName || generic.test(companyName) || companyName.length > 42)
    companyName = guessFromDomain;

  const description = meta(homeHtml, "description") || meta(homeHtml, "og:description");

  /* --- secondary page discovery --------------------------------- */
  const internal = links
    .map((h) => {
      try {
        return new URL(h, origin).href;
      } catch {
        return "";
      }
    })
    .filter((h) => h && h.startsWith(origin));

  const findPath = (words: string[]) =>
    internal.find((h) => {
      const p = new URL(h).pathname.toLowerCase();
      return words.some((w) => p === `/${w}` || p === `/${w}/` || p.startsWith(`/${w}/`));
    });

  const navBlogUrl =
    findPath(["blog", "insights", "resources", "articles", "news", "learn", "library", "ideas", "perspectives", "thinking"]) || null;
  const navPodcastUrl = findPath(["podcast", "podcasts", "show", "episodes"]) || null;
  const caseStudyUrl = findPath(["case-studies", "case-study", "customers", "success-stories", "clients", "work"]) || null;
  const pricingUrl = findPath(["pricing", "plans", "packages"]) || null;

  // Some sites render navigation client-side, so nav-link discovery misses the
  // content hub entirely. Probe the conventional paths directly as a fallback.
  let blogUrl = navBlogUrl;
  let podcastUrl = navPodcastUrl;

  if (!blogUrl || !podcastUrl) {
    const probes: [string, string][] = [];
    if (!blogUrl) for (const w of ["blog", "resources", "insights", "news"]) probes.push(["blog", `${origin}/${w}`]);
    if (!podcastUrl) probes.push(["podcast", `${origin}/podcast`]);
    const hits = await Promise.all(
      probes.map(async ([kind, u]) => {
        const r = await grab(u, 6000);
        return r.ok && r.body.length > 800 ? ([kind, u] as [string, string]) : null;
      })
    );
    for (const h of hits) {
      if (!h) continue;
      if (h[0] === "blog" && !blogUrl) blogUrl = h[1];
      if (h[0] === "podcast" && !podcastUrl) podcastUrl = h[1];
    }
  }

  const fetchList = [
    ["sitemap", `${origin}/sitemap.xml`],
    ["sitemapIndex", `${origin}/sitemap_index.xml`],
    ["blog", blogUrl],
    ["podcast", podcastUrl],
  ].filter((x) => !!x[1]) as [string, string][];

  const fetched: Record<string, string> = {};
  await Promise.all(
    fetchList.map(async ([k, u]) => {
      const r = await grab(u, 8000);
      if (r.ok) {
        fetched[k] = r.body;
        pagesScanned++;
      }
    })
  );

  // sitemap: follow one child sitemap if we got an index
  let sitemapXml = fetched.sitemap || fetched.sitemapIndex || "";
  if (/<sitemapindex/i.test(sitemapXml)) {
    const children = matchAllValues(sitemapXml, /<loc>\s*([^<\s]+)\s*<\/loc>/gi);
    const contentChild =
      children.find((c) => /post|blog|article|news|insight/i.test(c)) || children[0];
    if (contentChild) {
      const r = await grab(contentChild, 8000);
      if (r.ok) {
        sitemapXml = sitemapXml + r.body;
        pagesScanned++;
      }
    }
  }

  const sitemapLocs = matchAllValues(sitemapXml, /<loc>\s*([^<\s]+)\s*<\/loc>/gi);
  const sitemapCount = sitemapLocs.length;
  const contentUrlCount = sitemapLocs.filter((l) =>
    /\/(blog|post|posts|article|articles|news|insight|insights|resource|resources|guide|guides|episode|podcast)\//i.test(l)
  ).length;

  const lastmods = matchAllValues(sitemapXml, /<lastmod>\s*([^<\s]+)\s*<\/lastmod>/gi)
    .map((v) => Date.parse(v))
    .filter((n) => !Number.isNaN(n))
    .sort((a, b) => b - a);
  const daysSinceUpdate = lastmods.length
    ? Math.round((Date.now() - lastmods[0]) / 86_400_000)
    : null;

  const allHtml = homeHtml + (fetched.blog || "") + (fetched.podcast || "");
  const allLower = allHtml.toLowerCase();
  const allText = (homeText + " " + strip(fetched.blog || "") + " " + strip(fetched.podcast || "")).toLowerCase();

  /* ================================================================
     PILLAR 1 — Social presence (max 2.5)
     ================================================================ */
  const socialMap: Record<string, RegExp> = {
    LinkedIn: /linkedin\.com\/(company|school|in)\//i,
    YouTube: /youtube\.com\/(channel\/|c\/|@|user\/)/i,
    "X / Twitter": /(twitter\.com|x\.com)\/(?!share|intent|home)[a-z0-9_]{2,}/i,
    Instagram: /instagram\.com\/[a-z0-9_.]{2,}/i,
    Facebook: /facebook\.com\/(?!sharer|share|tr\?)[a-z0-9_.\-]{2,}/i,
    TikTok: /tiktok\.com\/@[a-z0-9_.]{2,}/i,
  };
  const socialFound = Object.entries(socialMap)
    .filter(([, re]) => re.test(allHtml))
    .map(([k]) => k);

  const hasLinkedIn = socialFound.includes("LinkedIn");
  let socialPts = 0;
  const socialEv: string[] = [];
  const socialPos: string[] = [];
  const socialNeg: string[] = [];

  if (socialFound.length === 0) {
    socialEv.push("No social profiles linked anywhere on the site");
  } else {
    socialPts += Math.min(0.8, socialFound.length * 0.2);
    socialEv.push(`${socialFound.length} channel${socialFound.length > 1 ? "s" : ""} linked: ${socialFound.join(", ")}`);
    socialPos.push(
      `${socialFound.length} channel${socialFound.length > 1 ? "s" : ""} linked (${socialFound.join(", ")})`
    );
    if (hasLinkedIn) {
      socialPts += 0.3;
      socialEv.push("LinkedIn company page present — the primary B2B authority channel");
      socialPos.push("a LinkedIn company page, the primary B2B authority channel");
    } else {
      socialEv.push("No LinkedIn company page linked — a meaningful gap for B2B credibility");
      socialNeg.push("a LinkedIn company page");
    }
    if (socialFound.length >= 4) {
      socialPts += 0.15;
      socialEv.push("Multi-channel distribution footprint");
    }
  }
  socialPts = Math.min(1.25, socialPts);
  const socialSummary = summarize(socialPos, socialNeg, "No social profiles are linked anywhere on the site.");

  /* ================================================================
     PILLAR 2 — Social effectiveness (max 1.25)
     Presence asks whether the channels exist. Effectiveness asks
     whether they are doing any work: people attached to the brand,
     activity surfaced on the site, and content built to travel.
     ================================================================ */
  let socialEffPts = 0;
  const socialEffEv: string[] = [];
  const socialEffPos: string[] = [];
  const socialEffNeg: string[] = [];

  // Named people, not just a company page — the strongest B2B authority signal.
  const personalProfiles = new Set(
    matchAllValues(allHtml, /linkedin\.com\/in\/([a-z0-9\-_%]{3,})/gi).map((s) => s.toLowerCase())
  );
  if (personalProfiles.size >= 2) {
    socialEffPts += 0.45;
    socialEffEv.push(`${personalProfiles.size} named people linked to personal LinkedIn profiles`);
    socialEffPos.push(`${personalProfiles.size} named people fronting the brand on LinkedIn`);
  } else if (personalProfiles.size === 1) {
    socialEffPts += 0.3;
    socialEffEv.push("One named individual linked to a personal LinkedIn profile");
    socialEffPos.push("one named individual fronting the brand on LinkedIn");
  } else {
    socialEffEv.push("No individual people linked — the brand has no human face on social");
    socialEffNeg.push("any named people fronting the brand");
  }

  // Live activity surfaced on the site itself.
  const embeddedFeed =
    /platform\.linkedin\.com|linkedin\.com\/embed|platform\.twitter\.com|twitter-timeline|instagram\.com\/embed|elfsight|juicer\.io|curator\.io|taggbox|sociablekit/i.test(
      allHtml
    );
  if (embeddedFeed) {
    socialEffPts += 0.35;
    socialEffEv.push("Live social feed embedded on the site — activity is surfaced, not just linked");
    socialEffPos.push("a live social feed embedded on the site");
  }

  // Stated audience size is a direct claim of reach.
  const followerClaim = allText.match(
    /\b(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?\s?(?:k|m|thousand|million)|\d{4,})\+?\s*(?:followers|subscribers|listeners)\b/i
  );
  if (followerClaim) {
    socialEffPts += 0.25;
    socialEffEv.push(`Audience size stated publicly (${followerClaim[0].trim()})`);
    socialEffPos.push(`a stated audience of ${followerClaim[1].trim()}`);
  }

  // Content built to travel when someone shares it.
  const shareTooling = /addtoany|sharethis|addthis|share-buttons|social-share|data-share|\bshare on (linkedin|twitter|x)\b/i.test(allHtml);
  const twitterCard = /name=["']twitter:card["']/i.test(homeHtml);
  const ogImage = !!meta(homeHtml, "og:image");
  const travelSignals = [shareTooling, twitterCard, ogImage].filter(Boolean).length;
  if (travelSignals >= 2) {
    socialEffPts += 0.35;
    socialEffEv.push("Pages are built to travel — share tooling and social preview cards in place");
    socialEffPos.push("share tooling and social preview cards");
  } else if (travelSignals === 1) {
    socialEffPts += 0.18;
    socialEffEv.push("Partial social preview setup — content loses formatting when shared");
  } else {
    socialEffEv.push("No share tooling or social preview cards — shared links render as bare URLs");
    socialEffNeg.push("social preview cards, so shared links render as bare URLs");
  }

  // Breadth plus a video channel indicates a real distribution habit.
  if (socialFound.length >= 3 && socialFound.includes("YouTube")) {
    socialEffPts += 0.25;
    socialEffEv.push("Distributes across three or more channels including video");
  }

  if (socialFound.length === 0) {
    socialEffPts = 0;
    socialEffEv.length = 0;
    socialEffPos.length = 0;
    socialEffNeg.length = 0;
    socialEffEv.push("No channels exist, so there is no social activity to evaluate");
  }
  socialEffPts = Math.min(1.25, socialEffPts);
  const socialEffSummary = summarize(
    socialEffPos,
    socialEffNeg,
    "Nothing on the site shows the social channels are actively working."
  );

  /* ================================================================
     PILLAR 3 — Content & SEO footprint (max 3.0)
     ================================================================ */
  let contentPts = 0;
  const contentEv: string[] = [];
  const contentPos: string[] = [];
  const contentNeg: string[] = [];

  if (blogUrl) {
    contentPts += 0.8;
    contentEv.push(`Content hub found at ${new URL(blogUrl).pathname}`);
    contentPos.push(`a content hub at ${new URL(blogUrl).pathname}`);
  } else {
    contentEv.push("No blog, insights, or resource hub found in site navigation");
    contentNeg.push("a blog or resource hub");
  }

  if (sitemapCount > 0) {
    if (sitemapCount >= 400) {
      contentPts += 1.0;
      contentEv.push(`Large indexed footprint — ${sitemapCount}+ URLs in sitemap`);
      contentPos.push(`a large indexed footprint (${sitemapCount}+ URLs)`);
    } else if (sitemapCount >= 120) {
      contentPts += 0.75;
      contentEv.push(`Substantial site — ${sitemapCount} URLs in sitemap`);
      contentPos.push(`substantial site depth (${sitemapCount} URLs)`);
    } else if (sitemapCount >= 35) {
      contentPts += 0.5;
      contentEv.push(`Moderate site depth — ${sitemapCount} URLs in sitemap`);
      contentPos.push(`moderate site depth (${sitemapCount} URLs)`);
    } else {
      contentPts += 0.2;
      contentEv.push(`Thin site — only ${sitemapCount} URLs in sitemap`);
      contentPos.push(`a thin site of only ${sitemapCount} URLs`);
    }
  } else {
    contentEv.push("No readable XML sitemap — limited SEO infrastructure");
    contentNeg.push("a readable sitemap");
  }

  if (contentUrlCount >= 60) {
    contentPts += 0.7;
    contentEv.push(`${contentUrlCount}+ published articles/posts indexed`);
    contentPos.push(`${contentUrlCount}+ published articles indexed`);
  } else if (contentUrlCount >= 15) {
    contentPts += 0.45;
    contentEv.push(`${contentUrlCount} published articles/posts indexed`);
    contentPos.push(`${contentUrlCount} published articles indexed`);
  } else if (contentUrlCount > 0) {
    contentPts += 0.2;
    contentEv.push(`Only ${contentUrlCount} article-level pages indexed — sparse publishing`);
    contentPos.push(`only ${contentUrlCount} article pages indexed`);
  }

  if (daysSinceUpdate !== null) {
    if (daysSinceUpdate <= 30) {
      contentPts += 0.5;
      contentEv.push(`Actively maintained — last content update ${daysSinceUpdate} day${daysSinceUpdate === 1 ? "" : "s"} ago`);
      contentPos.push("active maintenance");
    } else if (daysSinceUpdate <= 120) {
      contentPts += 0.3;
      contentEv.push(`Updated ~${Math.round(daysSinceUpdate / 30)} months ago — inconsistent cadence`);
      contentPos.push(`a last update about ${Math.round(daysSinceUpdate / 30)} months ago`);
    } else {
      contentEv.push(`Stale — no content update in ~${Math.round(daysSinceUpdate / 30)} months`);
      contentPos.push(`nothing new in about ${Math.round(daysSinceUpdate / 30)} months`);
    }
  }

  const hasSchema = /application\/ld\+json/i.test(homeHtml);
  const hasOg = !!meta(homeHtml, "og:title");
  const hasCanonical = /rel=["']canonical["']/i.test(homeHtml);
  const seoHygiene = [hasSchema, hasOg, hasCanonical, !!description].filter(Boolean).length;
  if (seoHygiene >= 3) {
    contentPts += 0.3;
    contentEv.push("Solid technical SEO hygiene (schema, OG tags, canonical, meta description)");
    contentPos.push("solid technical SEO hygiene");
  } else if (seoHygiene <= 1) {
    contentEv.push("Weak on-page SEO fundamentals — missing structured data and metadata");
    contentNeg.push("structured data and complete metadata");
  }

  const gatedAssets = /white\s?paper|e-?book|research report|benchmark report|download the guide|state of the/i.test(allText);
  if (gatedAssets) {
    contentPts += 0.25;
    contentEv.push("Publishes long-form assets (guides, reports, or whitepapers)");
    contentPos.push("published long-form assets");
  }

  const hasNewsletter = /newsletter|subscribe to our|weekly insights|join \d[\d,]* (subscribers|readers)/i.test(allText);
  if (hasNewsletter) {
    contentPts += 0.2;
    contentEv.push("Runs an owned email/newsletter channel");
    contentPos.push("an owned newsletter");
  }
  contentPts = Math.min(3.0, contentPts);
  const contentSummary = summarize(contentPos, contentNeg, "No meaningful owned content footprint was found.");

  /* ================================================================
     PILLAR 4 — Podcast (max 1.5)
     A linked show that has not published in years is not an asset.
     Presence is scored first, then discounted for inactivity.
     ================================================================ */
  let podPts = 0;
  const podEv: string[] = [];
  const podPos: string[] = [];
  const podNeg: string[] = [];
  const podPlatform = /podcasts\.apple\.com|open\.spotify\.com\/show|buzzsprout|libsyn|podbean|captivate\.fm|transistor\.fm|simplecast|anchor\.fm|megaphone\.fm|redcircle|spreaker/i.test(allHtml);
  const podWord = /\bpodcast\b/i.test(allText);
  const episodeLang = /episode\s*\d|ep\.\s*\d|listen now|all episodes|subscribe on apple/i.test(allText);

  if (podcastUrl || podPlatform) {
    podPts += 0.9;
    podEv.push(podcastUrl ? `Dedicated podcast page at ${new URL(podcastUrl).pathname}` : "Linked to podcast distribution platforms");
    podPos.push(podcastUrl ? `a dedicated podcast page at ${new URL(podcastUrl).pathname}` : "links to podcast distribution platforms");
    if (podPlatform) {
      podPts += 0.3;
      podEv.push("Distributed on Apple Podcasts / Spotify or a hosting platform");
      podPos.push("distribution on Apple or Spotify");
    }
    if (episodeLang) {
      podPts += 0.3;
      podEv.push("Episode-level content is visible and organized");
      podPos.push("organised episode-level content");
    }
  } else if (podWord) {
    podPts += 0.35;
    podEv.push("Mentions podcasting (likely guest appearances) but runs no owned show");
    podPos.push("podcasting mentioned, but no owned show");
  } else {
    podEv.push("No podcast — owned or guest — detected");
  }

  /* --- recency check: is the show actually still running? --------- */
  let podMonthsSince: number | null = null;
  if (podPts > 0.5) {
    const feedCandidates = Array.from(
      new Set(
        [
          ...matchAllValues(
            allHtml,
            /<link[^>]+type=["']application\/(?:rss|atom)\+xml["'][^>]*href=["']([^"']+)["']/gi
          ),
          ...matchAllValues(allHtml, /href=["']([^"']*(?:feed\.xml|rss\.xml|\/feed\/?|\/rss\/?)[^"']*)["']/gi),
          ...matchAllValues(allHtml, /["'](https?:\/\/(?:feeds?|rss)\.[^"'\s<>]+)["']/gi),
        ]
          .map((h) => {
            try {
              return new URL(h, origin).href;
            } catch {
              return "";
            }
          })
          .filter(Boolean)
      )
    )
      .sort((a, b) => {
        const rank = (u: string) => (/podcast|episode|show/i.test(u) ? 0 : 1);
        return rank(a) - rank(b);
      })
      .slice(0, 2);

    let newestMs: number | null = null;
    for (const f of feedCandidates) {
      const res = await grab(f, 6000);
      if (!res.ok || !/<(?:rss|feed|channel)[\s>]/i.test(res.body)) continue;
      pagesScanned++;
      const stamps = matchAllValues(
        res.body,
        /<(?:pubDate|lastBuildDate|published|updated)>\s*([^<]{6,60})</gi
      )
        .map((v) => Date.parse(v.trim()))
        .filter((n) => !Number.isNaN(n) && n < Date.now() + 86_400_000);
      if (stamps.length) {
        const max = Math.max(...stamps);
        newestMs = newestMs === null ? max : Math.max(newestMs, max);
      }
    }

    // Fallback: read visible years off the podcast page when no feed is exposed.
    if (newestMs === null && fetched.podcast) {
      const thisYear = new Date().getFullYear();
      const years = matchAllValues(strip(fetched.podcast), /\b(20[12]\d)\b/g)
        .map(Number)
        .filter((y) => y >= 2015 && y <= thisYear);
      if (years.length) newestMs = Date.parse(`${Math.max(...years)}-12-31`);
    }

    if (newestMs !== null) {
      podMonthsSince = Math.max(0, Math.round((Date.now() - newestMs) / 2_629_800_000));
      if (podMonthsSince <= 3) {
        podPts += 0.2;
        podEv.push(`Actively publishing — most recent episode about ${podMonthsSince} month${podMonthsSince === 1 ? "" : "s"} ago`);
        podPos.push("an active publishing cadence");
      } else if (podMonthsSince <= 12) {
        podPts -= 0.3;
        podEv.push(`Slowing down — nothing new in about ${podMonthsSince} months`);
        podPos.push(`nothing new in about ${podMonthsSince} months`);
      } else {
        podPts = Math.min(podPts, 0.45);
        podEv.push(`Dormant — no episode in roughly ${Math.round(podMonthsSince / 12)} year${podMonthsSince >= 24 ? "s" : ""}, so this counts as a dead link rather than an asset`);
        podPos.push(`no new episode in roughly ${Math.round(podMonthsSince / 12)} year${podMonthsSince >= 24 ? "s" : ""}`);
      }
    } else {
      podEv.push("Publishing cadence could not be verified — no readable feed or episode dates");
    }
  }

  podPts = Math.max(0, Math.min(1.5, podPts));
  const podSummary = summarize(podPos, podNeg, "No podcast — owned or guest — was detected.");

  /* ================================================================
     PILLAR 5 — Video (max 1.5)
     ================================================================ */
  let vidPts = 0;
  const vidEv: string[] = [];
  const vidPos: string[] = [];
  const vidNeg: string[] = [];
  const ytChannel =
    /youtube\.com\/(channel\/|c\/|@|user\/)/i.test(allHtml) ||
    /youtube\.com\/(?!watch|embed|results|playlist|shorts|feed|channel|c\/|@|user)[a-z0-9_-]{3,}/i.test(allHtml);
  const embeds =
    count(allHtml, /youtube\.com\/embed|youtu\.be\//gi) +
    count(allHtml, /player\.vimeo\.com|vimeo\.com\/\d/gi) +
    count(allHtml, /wistia|vidyard|loom\.com\/(share|embed)|brightcove/gi);
  const nativeVideo = count(allHtml, /<video[\s>]/gi);
  const webinar = /\bwebinar|on-?demand video|watch the (demo|replay|session)/i.test(allText);

  if (ytChannel) {
    vidPts += 0.6;
    vidEv.push("Owned YouTube channel linked");
    vidPos.push("an owned YouTube channel");
  } else {
    vidNeg.push("an owned video channel");
  }
  if (embeds >= 3) {
    vidPts += 0.6;
    vidEv.push(`${embeds} video embeds across scanned pages — video is a core format`);
    vidPos.push(`${embeds} video embeds across the site`);
  } else if (embeds > 0) {
    vidPts += 0.35;
    vidEv.push(`${embeds} video embed${embeds > 1 ? "s" : ""} found — video used selectively`);
    vidPos.push(`${embeds} video embed${embeds > 1 ? "s" : ""}, used selectively`);
  } else if (nativeVideo > 0) {
    vidPts += 0.2;
    vidEv.push("Background/native video used, but no distributed video library");
    vidPos.push("background video on the site");
    vidNeg.push("a distributed video library");
  } else {
    vidNeg.push("any video embedded on the site");
  }
  if (webinar) {
    vidPts += 0.3;
    vidEv.push("Runs webinars or on-demand video sessions");
    vidPos.push("webinars or on-demand sessions");
  }
  if (vidPts === 0) vidEv.push("No video presence detected — no channel, embeds, or webinars");
  vidPts = Math.min(1.5, vidPts);
  const vidSummary = summarize(vidPos, vidNeg, "No video presence was detected anywhere on the site.");

  /* ================================================================
     PILLAR 6 — Third-party validation (max 1.5)
     ================================================================ */
  let extPts = 0;
  const extEv: string[] = [];
  const extPos: string[] = [];
  const extNeg: string[] = [];
  const reviewSites = [
    ["G2", /g2\.com|g2crowd/i],
    ["Capterra", /capterra\.com/i],
    ["TrustRadius", /trustradius\.com/i],
    ["Trustpilot", /trustpilot\.com/i],
    ["Clutch", /clutch\.co/i],
    ["Software Advice", /softwareadvice\.com/i],
    ["Gartner Peer Insights", /gartner\.com\/reviews|peerinsights/i],
  ]
    .filter(([, re]) => (re as RegExp).test(allHtml))
    .map(([n]) => n as string);

  if (reviewSites.length) {
    extPts += Math.min(0.7, 0.4 + reviewSites.length * 0.15);
    extEv.push(`Listed on B2B review platforms: ${reviewSites.join(", ")}`);
    extPos.push(`listings on ${reviewSites.join(", ")}`);
  } else {
    extEv.push("No G2, Capterra, or comparable review-platform badges surfaced on the site");
    extNeg.push("any third-party review-platform presence");
  }

  const pressRoom = /\b(press|media kit|in the news|as seen (in|on)|newsroom|press release)\b/i.test(allText);
  if (pressRoom) {
    extPts += 0.3;
    extEv.push("Maintains a press/newsroom or earned-media section");
    extPos.push("a press or earned-media section");
  }
  const speaking = /\b(keynote|speaking|conference|summit|panel|award|recognized by|named a leader|top \d+)\b/i.test(allText);
  if (speaking) {
    extPts += 0.3;
    extEv.push("References speaking engagements, awards, or industry recognition");
    extPos.push("speaking engagements, awards, or industry recognition");
  }
  const socialProof = /\btestimonial|trusted by|case stud|client results|success stor/i.test(allText) || !!caseStudyUrl;
  if (socialProof) {
    extPts += 0.25;
    extEv.push("Publishes customer proof (case studies or testimonials)");
    extPos.push("published customer proof");
  }
  if (extPts === 0)
    extEv.push("No press, awards, speaking, or customer proof — credibility lives entirely on this one site");
  extPts = Math.min(1.5, extPts);
  const extSummary = summarize(
    extPos,
    extNeg,
    "No press, awards, speaking, or customer proof was found — every claim about them comes from them."
  );

  /* ================================================================
     Audience & offer classification
     ================================================================ */
  const b2bHits = [
    /\bb2b\b/i, /\benterprise\b/i, /request a demo|book a demo|schedule a demo|get a demo/i,
    /\bsaas\b/i, /\bplatform\b/i, /\bintegrations?\b/i, /\bapi\b/i, /\broi\b/i,
    /case stud/i, /\bwhite\s?paper\b/i, /\bprocurement\b/i, /\bsla\b/i,
    /per (seat|user|month)/i, /talk to sales|contact sales/i, /for (teams|businesses|companies|organizations)/i,
    /\bconsulting\b/i, /\bagency\b/i, /\bclients\b/i, /\bworkflow\b/i, /\bcompliance\b/i,
  ].filter((re) => re.test(textLower)).length;

  const b2cHits = [
    /add to (cart|bag)/i, /free shipping/i, /\bcheckout\b/i, /shop (now|all)/i,
    /my account/i, /\bsale\b.{0,12}\boff\b/i, /gift card/i, /\bmenu\b.{0,20}\border\b/i,
    /subscribe (and|&) save/i, /product reviews/i, /\bsizes?\b.{0,20}\bcolors?\b/i,
  ].filter((re) => re.test(textLower)).length;

  let audience: ScoreResult["audience"] = "Unclear";
  let audienceNote = "";
  if (b2bHits >= 3 && b2cHits >= 3) {
    audience = "Mixed";
    audienceNote = "Signals point to both business and consumer buyers.";
  } else if (b2bHits >= 3 && b2bHits > b2cHits) {
    audience = "B2B";
    audienceNote = "Language, CTAs, and proof points are aimed at business buyers.";
  } else if (b2cHits >= 3 && b2cHits > b2bHits) {
    audience = "B2C";
    audienceNote = "Commerce and consumer-facing language dominates the site.";
  } else if (b2bHits >= 1) {
    audience = "B2B";
    audienceNote = "Leans business-to-business, though positioning language is thin.";
  } else {
    audienceNote = "Not enough positioning language on the site to classify the buyer confidently.";
  }

  const ctaSignals = /contact us|get started|book a call|schedule a call|request a quote|talk to us|free trial|sign up|get a demo|apply now/i.test(textLower);
  const offerNav = /\b(services|solutions|products?|what we do|pricing|plans|how it works)\b/i.test(textLower);
  let sellingRealOffer: ScoreResult["sellingRealOffer"] = "Unclear";
  let sellingNote = "";
  if ((ctaSignals && offerNav) || pricingUrl) {
    sellingRealOffer = "Yes";
    sellingNote = pricingUrl
      ? "Clear offer with a published pricing or plans page and active conversion paths."
      : "Clear offer with defined services/products and active conversion CTAs.";
  } else if (ctaSignals || offerNav) {
    sellingRealOffer = "Likely";
    sellingNote = "An offer is implied, but the commercial path is underdeveloped.";
  } else {
    sellingNote = "No clear offer, pricing, or conversion path visible on the homepage.";
  }

  /* ================================================================
     Score assembly
     ================================================================ */
  const mk = (
    key: string,
    label: string,
    earned: number,
    max: number,
    summary: string,
    evidence: string[]
  ): Pillar => {
    const tier = tierOf(earned, max);
    return {
      key,
      label,
      earned: Math.round(earned * 100) / 100,
      max,
      status: tier,
      summary,
      consequence: CONSEQUENCE[key][tier],
      evidence,
    };
  };

  const pillars: Pillar[] = [
    mk("social", "Social Presence", socialPts, 1.25, socialSummary, socialEv),
    mk("socialEff", "Social Effectiveness", socialEffPts, 1.25, socialEffSummary, socialEffEv),
    mk("content", "Content & SEO Footprint", contentPts, 3.0, contentSummary, contentEv),
    mk("podcast", "Podcast", podPts, 1.5, podSummary, podEv),
    mk("video", "Video", vidPts, 1.5, vidSummary, vidEv),
    mk("external", "Third-Party Validation", extPts, 1.5, extSummary, extEv),
  ];

  const raw = pillars.reduce((s, p) => s + p.earned, 0);
  const score = Math.max(0, Math.min(10, Math.round(raw)));

  const bands: Record<string, { band: string; label: string; headline: string }> = {
    invisible: { band: "0", label: "Invisible", headline: "No meaningful authority presence." },
    minimal: { band: "1\u20132", label: "Minimal", headline: "They exist online. Almost no one would find them." },
    emerging: { band: "3\u20134", label: "Emerging", headline: "Some presence, but it isn't consistent enough to compound." },
    moderate: { band: "5\u20137", label: "Established", headline: "Real presence. Not yet a category voice." },
    dominant: { band: "8\u201310", label: "Dominant", headline: "They are already a recognized authority in their market." },
  };
  const bandKey =
    score === 0 ? "invisible" : score <= 2 ? "minimal" : score <= 4 ? "emerging" : score <= 7 ? "moderate" : "dominant";
  const b = bands[bandKey];

  const sorted = [...pillars].sort((a, c) => a.earned / a.max - c.earned / c.max);
  const weakest = sorted[0];
  const secondWeakest = sorted[1];
  const strongest = [...pillars].sort((a, c) => c.earned / c.max - a.earned / a.max)[0];

  const gapCopy: Record<string, string> = {
    social: "Social distribution is the constraint — content that isn't distributed doesn't build authority.",
    socialEff: "Their social channels exist but aren't working — presence without activity persuades no one.",
    content: "Owned content is the constraint — there is no compounding asset base to rank, cite, or repurpose.",
    podcast: "No owned show — they're missing the highest-trust, longest-attention format available to them.",
    video: "No video engine — the format buyers use most to evaluate expertise is absent.",
    external: "Third-party validation is the constraint — all credibility currently lives on their own website.",
  };

  /* Rationale, written from the buyer's point of view: what someone
     researching this company actually encounters before making contact. */
  const who = companyName || domain;
  const strongPillars = pillars.filter((p) => p.earned / p.max >= 0.6);
  const missingPillars = pillars.filter((p) => p.earned / p.max < 0.3);
  const list = (items: string[]) =>
    items.length <= 1
      ? items[0] ?? ""
      : `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;

  const rationaleParts: string[] = [];
  rationaleParts.push(
    strongPillars.length
      ? `A buyer researching ${who} today would find ${list(strongPillars.map((p) => p.label.toLowerCase()))} — enough to confirm they are real and operating.`
      : `A buyer researching ${who} today would find their website and very little else — not enough to confirm they are the credible choice.`
  );
  if (missingPillars.length) {
    rationaleParts.push(
      `Where the competitor's presence falls short: ${list(missingPillars.map((p) => p.label.toLowerCase()))}. Buyers may look to these channels when deciding whether the company is worth contacting.`
    );
    rationaleParts.push(
      `That gap between what exists and what a buyer needs to see is the score: ${score} out of 10.`
    );
  } else {
    rationaleParts.push(
      `Weighed against what a buyer needs to see before they reach out, that puts them at ${score} out of 10.`
    );
  }
  if (score <= 2)
    rationaleParts.push(
      "At this level almost every buyer forms their impression of them from a single page, then leaves to look at someone they can learn more about."
    );
  else if (score <= 4)
    rationaleParts.push(
      "They are findable but forgettable. Buyers encounter them once, get no reason to return, and give the shortlist slot to whoever showed up more often."
    );
  else if (score <= 7)
    rationaleParts.push(
      "The foundation is genuinely there. What is missing is the repetition and format coverage that turns a company buyers can find into the one they assume is the leader."
    );
  else
    rationaleParts.push(
      "Buyers encounter them repeatedly and from multiple directions before they ever make contact. That is what authority looks like in practice — the work now is defending it."
    );

  const recommended = score >= 2 && score <= 7 && audience !== "B2C";
  let recommendation: string;
  if (audience === "B2C") {
    recommendation =
      "This reads as a consumer brand. B2B thought-leadership mechanics apply differently here — worth a conversation before committing to an authority program.";
  } else if (score <= 1) {
    recommendation =
      "Presence is near-zero. Before authority-building, the fundamentals need to be in place — positioning, a content home, and at least one active channel.";
  } else if (score <= 4) {
    recommendation =
      "This is the highest-leverage position on the scale. They have a business worth talking about and almost no competition for their own narrative, which means every unit of authority they build converts directly into deals their competitors never see.";
  } else if (score <= 7) {
    recommendation =
      "They have the raw materials to build an authority presence that lets prospects validate them on their own and reach out already convinced. Closing the remaining gaps turns visibility into pipeline — more authority, more deals, at higher margin.";
  } else {
    recommendation =
      "They're already dominant. The opportunity is optimization and defense, not construction. A build-from-zero authority program is not the right fit.";
  }

  const presenceNotes: string[] = [];
  presenceNotes.push(
    socialFound.length ? `Social: ${socialFound.join(", ")}.` : "Social: no profiles linked from the site."
  );
  presenceNotes.push(
    blogUrl || contentUrlCount > 0
      ? `Content: ${contentUrlCount > 0 ? `${contentUrlCount} indexed article pages` : "content hub present"}${
          daysSinceUpdate !== null ? `, last updated ~${daysSinceUpdate} days ago` : ""
        }.`
      : "Content: no blog or resource hub found."
  );
  presenceNotes.push(podcastUrl || podPlatform ? "Podcast: active show detected." : "Podcast: none detected.");
  presenceNotes.push(ytChannel || embeds > 0 ? "Video: in use." : "Video: none detected.");
  presenceNotes.push(
    reviewSites.length ? `Review platforms: ${reviewSites.join(", ")}.` : "Review platforms: not listed."
  );

  /* --- the three summary boxes ------------------------------------ */
  const offerAnswer =
    sellingRealOffer === "Yes" ? "Yes" : sellingRealOffer === "Likely" ? "Mostly" : "Not clearly";

  // Never a flat "Yes" — positioning is almost always partially legible at best.
  const audienceAnswer =
    audience === "Unclear"
      ? "Not clearly"
      : audience === "Mixed"
      ? "Somewhat"
      : b2bHits + b2cHits >= 8
      ? `Yes, ${audience}`
      : b2bHits + b2cHits >= 4
      ? `Mostly, ${audience}`
      : `Somewhat, ${audience}`;

  // Box three is competitive standing, not scan reliability.
  const standing = score <= 2 ? "Invisible" : score <= 4 ? "Behind" : score <= 7 ? "In the pack" : "Ahead";
  const standingNote =
    score <= 2
      ? "Against any competitor doing even basic authority work, they do not appear in the consideration set at all. Buyers are not choosing against them — they never see them."
      : score <= 4
      ? "This competitor has a limited authority footprint. Companies with a broader presence may give buyers more opportunities to encounter their expertise."
      : score <= 7
      ? "They show up where buyers look, but so does everyone else on their shortlist. Nothing yet separates them as the obvious authority, so the deal comes down to price and timing instead of standing."
      : "They reach buyers more often and from more directions than the companies they compete with. That is the position where prospects arrive pre-sold and competitors are compared to them.";

  const evidenceDepth = pagesScanned + (sitemapCount > 0 ? 2 : 0) + (socialFound.length ? 1 : 0);
  const confidence: ScoreResult["confidence"] =
    evidenceDepth >= 6 ? "High" : evidenceDepth >= 4 ? "Moderate" : "Limited";
  const confidenceNote =
    confidence === "High"
      ? `Scored on ${pagesScanned} fetched pages plus sitemap and off-site link signals.`
      : confidence === "Moderate"
      ? `Scored on ${pagesScanned} fetched pages. Some signals were not machine-readable — the true score may be modestly higher.`
      : `Limited public evidence was readable (${pagesScanned} page${pagesScanned > 1 ? "s" : ""}). This site may block automated visitors or run heavy client-side rendering. Treat the score as directional.`;

  return {
    companyName,
    url: base,
    domain,
    audience,
    audienceNote,
    audienceAnswer,
    sellingRealOffer,
    sellingNote,
    offerAnswer,
    standing,
    standingNote,
    score,
    band: b.band,
    bandLabel: b.label,
    headline: b.headline,
    rationale: rationaleParts.join(" "),
    presenceNotes,
    recommended,
    recommendation,
    pillars,
    biggestGap: gapCopy[weakest.key],
    confidence,
    confidenceNote,
    pagesScanned,
  };
}
